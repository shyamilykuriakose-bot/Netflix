# Netflix Power BI Project

## Main file
- `Netflix.pbix` — Power BI dashboard/report

## Dashboard page
- Page 2

## Visuals
- 5 KPI cards
- Top 10 Countries treemap
- Movies vs TV Shows donut chart
- TV/Movies by release year area chart
- Ratings clustered bar chart
- Directors clustered column chart

## Main fields
- show_id
- type
- title
- director
- country
- release_year
- rating
